<!DOCTYPE html>
<html lang="en" class="no-js">
   <head>
  
      <meta name="google-site-verification" content="5Zs5QR_4qPJk8wyuKvOup4NI3vloBcqwEq8_EDHDMMc" />
      <meta charset="utf-8"/>
      <title>Elancier | <?php echo ($title !='') ? $title :'Website Design Company in Madurai, Website Design in Madurai';?> </title>
      <meta name="description" content="Elancier is a web services company based in Madurai, Website development, mobile application development, custom web development">
      <meta name="keywords" content="Mobile App Development Company,  Professional Web Designing, Madurai, Web design in Madurai,  Web Development Company in Madurai. Mobile apps developer, web designing in Madurai,  website designer, web page design service, web page design company, web web hosting, web design">
      <meta name="author" content="Elancier">
      <meta property="og:image" content="">
  
      <meta property="og:image:type" content="image/jpeg">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="theme-color" content="#2e2a8f">
      <!--website-favicon-->
      <link href="images/favicon.png" rel="icon">
      <!--plugin-css-->
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/plugin.min.css" rel="stylesheet">
      <link href="css/all.min.css" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
      
      <link href="css/style.css" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="css/custom.css">
      <link href="css/responsive.css" rel="stylesheet">
   </head>
   <body>
