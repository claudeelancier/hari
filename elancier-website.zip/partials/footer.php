<!--Start CTA-->
<section class="cta-area pad-tb">
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-lg-8">
            <div class="common-heading">
               <span>Let's work together</span>
               <h2>We Love to Listen to Your Requirements</h2>
               <a href="contact.php" class="btn-outline">Share Your Thoughts 
                  <i class="fas fa-chevron-right fa-icon"></i></a>
               <h4 class="or_text">Or you can feel free call and mail us</h4>
               <div class="dis_flex">
               <p class="cta-call"> <a href="tel:+918144688721">
                  <i class="fas fa-phone-alt"></i> +91 81446 88721</a></p>
               <p class="cta-call"><a href = "mailto: admin@elancier.com">
               <i class="fas fa-envelope"></i> admin@elancier.com</a></p>
            </div>
            </div>
         </div>
      </div>
   </div>
   <div class="shape shape-a1"><img src="images/shape/shape-3.svg" alt="shape"></div>
   <div class="shape shape-a2"><img src="images/shape/shape-4.svg" alt="shape"></div>
   <div class="shape shape-a3"><img src="images/shape/shape-13.svg" alt="shape"></div>
   <div class="shape shape-a4"><img src="images/shape/shape-11.svg" alt="shape"></div>
</section>
<!--End CTA-->
<footer>
   <div class="footer-row2 pb50 bg-light-f7">
      <div class="container">
         <div class="row justify-content-center">
            <div class="col-lg-12 col-sm-12 text-center">
               <a class="navbar-brand img-ctr footer-logo" href="#"><img src="images/logo.png" alt="Logo"/></a>
               <ul class="footer-link-v2 link-hover mt30">
               	  <li><a href="index.php">Home</a></li>
                  <li><a href="about-us.php">About Us</a></li>
                  <li><a href="web-development.php">Services</a></li>
                  <li><a href="careers.php">Career</a></li>
                  <li><a href="contact.php">Contact Us</a></li>
               </ul>
            </div>
         </div>
      </div>
   </div>
   <hr class="hline">
   <div class="footer-row3">
      <div class="copyright">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="footer-social-media-icons">
                     <a href="https://www.facebook.com/elanciersolutions/?ref=aymt_homepage_panel" target="blank"><i class="fab fa-facebook"></i></a>
                     <a href="https://twitter.com/elanciermdu" target="blank"><i class="fab fa-twitter"></i></a>
                     <a href="https://www.instagram.com/elanciersolutions/" target="blank"><i class="fab fa-instagram"></i></a>
                     <a href="https://in.linkedin.com/company/elanciersolutions" target="blank"><i class="fab fa-linkedin"></i></a>			
                  </div>
                  <div class="footer-">
                     <p>Copyright &copy; 2026 All Rights Reserved. Elancier</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</footer>
<!--End Footer V5-->
<!-- js placed at the end of the document so the pages load faster -->
<script src="js/vendor/modernizr-3.5.0.min.js"></script>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script> 
<script src="js/plugin.min.js"></script>
<!--common script file-->
<script src="js/main.js"></script>
<script src="js/custom.js"></script>
</body>
</html>